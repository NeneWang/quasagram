<template>
  <q-page class="flex flex-center">
    <h5>Camera Page</h5>
  </q-page>
</template>

<script>
export default {
  name: 'PageCamera'
}
</script>
