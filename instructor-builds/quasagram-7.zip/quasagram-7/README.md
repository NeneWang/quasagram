# Quasagram

## Install the dependencies
```bash
npm install
```

### Start the app in development mode
```bash
quasar dev
```

### Build the app for production
```bash
quasar build
```